// Vincy Vans Drift — multiplayer server.
//  • One Durable Object per room code. Players connect with a WebSocket to /room/<CODE>.
//    The room relays van positions, horns, chat, room races and the voice-chat handshakes (the voice itself goes player to player).
//  • One "Lobby" Durable Object keeps the list of live rooms, for the owner's admin view.
//  • WebSocket Hibernation: between messages a room costs nothing to keep open.

const MAX_PLAYERS = 12;       // vans per room (watching admins don't count)
const MAX_MSG = 6000;         // bytes; voice handshakes can be a few KB
const VANS = ['bussup', 'seen', 'ovaz', 'blaze', 'jook', 'haulya', 'lago', 'skata'];
const ROUTES = ['biabou', 'mespo', 'stubbs', 'tung', 'gap', 'rabacca', 'leeward'];
const CORS = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-allow-headers': 'content-type' };
const json = (o, s) => new Response(JSON.stringify(o), { status: s || 200, headers: { 'content-type': 'application/json', ...CORS } });
const same = (a, b) => typeof a === 'string' && typeof b === 'string' && a.length > 0 && a.length === b.length && [...a].every((ch, i) => ch === b[i]);

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (url.pathname === '/' || url.pathname === '/health') return new Response('Vincy Vans multiplayer is running', { headers: { 'content-type': 'text/plain', ...CORS } });

    // voice chat: STUN always; TURN relay too when a Cloudflare TURN key is set up
    if (url.pathname === '/ice') {
      const stun = [{ urls: ['stun:stun.cloudflare.com:3478'] }];
      if (!env.TURN_KEY_ID || !env.TURN_KEY_API_TOKEN) return json({ iceServers: stun });
      try {
        const r = await fetch('https://rtc.live.cloudflare.com/v1/turn/keys/' + env.TURN_KEY_ID + '/credentials/generate-ice-servers', {
          method: 'POST', headers: { authorization: 'Bearer ' + env.TURN_KEY_API_TOKEN, 'content-type': 'application/json' }, body: JSON.stringify({ ttl: 86400 }) });
        const d = await r.json();
        return json({ iceServers: d.iceServers || stun });
      } catch (e) { return json({ iceServers: stun }); }
    }

    // the owner's view of every live room (POST the admin key as the body)
    if (url.pathname === '/rooms') {
      const key = req.method === 'POST' ? (await req.text()).trim() : '';
      if (!same(key, env.ADMIN_KEY || '')) return json({ error: 'wrong key' }, 403);
      const lobby = env.LOBBY.get(env.LOBBY.idFromName('lobby'));
      const r = await lobby.fetch('https://lobby/list');
      return json(await r.json());
    }

    const m = url.pathname.match(/^\/room\/([A-Za-z0-9_-]{1,24})$/);
    if (!m) return new Response('Not found', { status: 404, headers: CORS });
    if (req.headers.get('Upgrade') !== 'websocket') return new Response('Expected a WebSocket', { status: 426, headers: CORS });
    const code = m[1].toUpperCase();
    const stub = env.ROOMS.get(env.ROOMS.idFromName(code));
    const h = new Headers(req.headers); h.set('x-room', code);
    return stub.fetch(new Request(req, { headers: h }));
  }
};

export class Room {
  constructor(ctx, env) { this.ctx = ctx; this.env = env; }

  socks() { return this.ctx.getWebSockets(); }
  info(ws) { try { return ws.deserializeAttachment() || {}; } catch (e) { return {}; } }
  send(ws, o) { try { ws.send(typeof o === 'string' ? o : JSON.stringify(o)); } catch (e) {} }
  // to everyone who has joined (watching admins included, so they see and hear the room)
  all(o, except) { const s = JSON.stringify(o); for (const w of this.socks()) if (w !== except && this.info(w).id) this.send(w, s); }
  byId(id) { return this.socks().find(w => this.info(w).id === id); }
  members() { return this.socks().map(w => this.info(w)).filter(p => p.id && !p.watch); }
  players() { return this.members().map(p => ({ id: p.id, name: p.name, van: p.van, mic: !!p.mic, admin: !!p.admin })); }
  host() { const p = this.members().sort((a, b) => a.joined - b.joined)[0]; return p ? p.id : null; }
  async code() { return (await this.ctx.storage.get('code')) || '?'; }
  async report() {   // tell the lobby who is in here
    try {
      const lobby = this.env.LOBBY.get(this.env.LOBBY.idFromName('lobby'));
      const race = await this.ctx.storage.get('race');
      await lobby.fetch('https://lobby/report', { method: 'POST', body: JSON.stringify({ code: await this.code(), players: this.players(), race: race && race.startAt > Date.now() - 20 * 60000 ? race.route : null }) });
    } catch (e) {}
  }

  async fetch(req) {
    const code = req.headers.get('x-room');
    if (code && !(await this.ctx.storage.get('code'))) await this.ctx.storage.put('code', code);
    if (this.socks().length >= MAX_PLAYERS + 4) return new Response('Room full', { status: 429 });
    const pair = new WebSocketPair();
    this.ctx.acceptWebSocket(pair[1]);
    pair[1].serializeAttachment({});
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async webSocketMessage(ws, raw) {
    if (typeof raw !== 'string' || raw.length > MAX_MSG) return;
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    const me = this.info(ws);

    // first message: who you are (the owner adds the admin key; "watch" joins unseen)
    if (m.t === 'hi') {
      if (me.id) return;
      const admin = same(m.admin, this.env.ADMIN_KEY || '');
      const watch = admin && !!m.watch;
      if (!watch && this.members().length >= MAX_PLAYERS) { this.send(ws, { t: 'full' }); try { ws.close(1000, 'full'); } catch (e) {} return; }
      const id = Math.random().toString(36).slice(2, 8);
      const name = String(m.name || 'Driver').replace(/[^\w .'-]/g, '').slice(0, 16) || 'Driver';
      const van = VANS.includes(m.van) ? m.van : 'bussup';
      ws.serializeAttachment({ id, name, van, joined: Date.now(), admin, watch, mic: false });
      const race = (await this.ctx.storage.get('race')) || null;
      this.send(ws, { t: 'welcome', id, players: this.players(), host: this.host(), now: Date.now(), race, admin, watch, room: await this.code() });
      if (!watch) { this.all({ t: 'join', id, name, van, admin }, ws); await this.report(); }
      return;
    }
    if (!me.id) return;

    switch (m.t) {
      case 's':   // where my van is: [x,y,z,heading,speed,steer,flags,time]
        if (!me.watch && Array.isArray(m.p) && m.p.length <= 8) this.all({ t: 's', id: me.id, p: m.p }, ws);
        break;
      case 'van':
        if (VANS.includes(m.van)) { me.van = m.van; ws.serializeAttachment(me); if (!me.watch) this.all({ t: 'van', id: me.id, van: m.van }, ws); }
        break;
      case 'horn':
        if (!me.watch) this.all({ t: 'horn', id: me.id }, ws);
        break;
      case 'chat':
        this.all({ t: 'chat', id: me.id, name: me.name, m: String(m.m || '').slice(0, 80) });
        break;
      case 'ping':
        this.send(ws, { t: 'pong', c: m.c, s: Date.now() });
        break;
      case 'mic':   // my mic is on / off (shown next to my name)
        me.mic = !!m.on; ws.serializeAttachment(me); this.all({ t: 'mic', id: me.id, on: me.mic }, ws);
        break;
      case 'rtc': { // voice-chat handshake, passed straight to the one player it's for
        const to = this.byId(m.to); if (to) this.send(to, { t: 'rtc', from: me.id, admin: !!me.admin, d: m.d });
        break;
      }
      case 'race': {  // the host (or the owner) starts a room race: same route, same green light for everyone
        if ((me.id !== this.host() && !me.admin) || !ROUTES.includes(m.route)) return;
        const race = { n: Date.now(), route: m.route, tod: typeof m.tod === 'number' ? m.tod : null, startAt: Date.now() + 7000, by: me.name, results: [] };
        await this.ctx.storage.put('race', race);
        this.all({ t: 'race', race });
        await this.report();
        break;
      }
      case 'fin': {
        const race = await this.ctx.storage.get('race');
        if (me.watch || !race || race.n !== m.n || race.results.some(r => r.id === me.id)) return;
        const time = Number(m.time); if (!(time > 0 && time < 7200)) return;
        race.results.push({ id: me.id, name: me.name, van: me.van, time });
        race.results.sort((a, b) => a.time - b.time);
        await this.ctx.storage.put('race', race);
        this.all({ t: 'board', n: race.n, route: race.route, results: race.results });
        break;
      }
      // ---- the owner's powers ----
      case 'kick': {
        if (!me.admin) return;
        const w = this.byId(m.id); if (!w) return;
        this.send(w, { t: 'kicked' }); this.left(w);
        break;
      }
      case 'say':
        if (me.admin) this.all({ t: 'announce', m: String(m.m || '').slice(0, 120) });
        break;
    }
  }

  async webSocketClose(ws) { await this.left(ws); }
  async webSocketError(ws) { await this.left(ws); }
  async left(ws) {
    const me = this.info(ws); if (!me.id) return;
    ws.serializeAttachment({});
    try { ws.close(1000, 'bye'); } catch (e) {}
    this.all({ t: 'leave', id: me.id, host: this.host() });
    if (!me.watch) await this.report();
  }
}

// the list of live rooms: each room reports itself whenever someone joins or leaves
export class Lobby {
  constructor(ctx, env) { this.ctx = ctx; this.env = env; }
  async fetch(req) {
    const url = new URL(req.url);
    if (url.pathname === '/report' && req.method === 'POST') {
      const r = await req.json();
      const code = String(r.code || '').slice(0, 24);
      if (!code || code === '?') return new Response('ok');
      if (!r.players || !r.players.length) await this.ctx.storage.delete('room:' + code);
      else await this.ctx.storage.put('room:' + code, { code, players: r.players.slice(0, 16), race: r.race || null, t: Date.now() });
      return new Response('ok');
    }
    if (url.pathname === '/list') {
      const all = await this.ctx.storage.list({ prefix: 'room:' });
      const rooms = [];
      const stale = Date.now() - 12 * 3600 * 1000;
      for (const [k, v] of all) { if (v.t < stale) { await this.ctx.storage.delete(k); continue; } rooms.push(v); }
      rooms.sort((a, b) => b.players.length - a.players.length);
      return new Response(JSON.stringify({ rooms, now: Date.now() }), { headers: { 'content-type': 'application/json' } });
    }
    return new Response('Not found', { status: 404 });
  }
}
