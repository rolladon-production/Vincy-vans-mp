# Vincy Vans Drift: multiplayer server

This is the online part of the game. Each room code (for example `ISLAND`) is its own small live server on Cloudflare (a Durable Object). Everyone who types the same room code is on the same island:

- you see each other's vans with name tags, can bump each other and hear each other's horns
- **voice chat:** each player turns their own mic on or off. Voices go straight from player to player; the server only passes the connection handshake
- **room races:** the host starts a street race for everyone, with one countdown and a shared finish board
- **owner powers (you):** with your admin key you can see every live room and who's in it, and:
  - join any room, or watch it without being seen
  - jump to any driver
  - remove a player
  - send a message to the whole room

## What's in here

| File | What it is |
|---|---|
| `wrangler.toml` | The worker's name (`vincy-vans-mp`) and its two Durable Objects: `Room` (one per room) and `Lobby` (the list of live rooms) |
| `src/worker.js` | The server: rooms, positions, horn, voice handshakes, room races, the live-room list and the owner's powers |
| `package.json` | Lets Cloudflare install its deploy tool (wrangler) |

## Put it online (no computer setup needed)

1. **GitHub:** create a new repository named `vincy-vans-mp`. Choose **uploading an existing file** and drag in `wrangler.toml`, `package.json`, `README.md` and the `src` folder. Then press **Commit changes**.
2. **Cloudflare:** go to **Workers & Pages**, then **Create application**, then **GitHub**, and pick the `vincy-vans-mp` repository. Keep the name `vincy-vans-mp`; it must match `name` in `wrangler.toml`. Press **Save and Deploy**.
3. **Your admin key:** in Cloudflare, open the `vincy-vans-mp` Worker, go to **Settings**, then **Variables and Secrets**, then **Add**. Pick type **Secret**, name it `ADMIN_KEY`, and give it a long password only you know. Save; Cloudflare redeploys automatically.
4. Open the address Cloudflare gives you, which looks like `https://vincy-vans-mp.YOURNAME.workers.dev`. You should see **"Vincy Vans multiplayer is running"**.
5. Put that address into the game. Either:
   - set `MP_DEFAULT` in the game's code (Claude can do this and rebuild the zip), or
   - paste it into the **Server** box in the game's **Online** panel. That only sets it for you.

### Optional: voice for players on strict mobile networks

Voice usually connects player to player directly. Some mobile carriers and work Wi-Fi block that. For those players, add Cloudflare's TURN relay:

1. In the Cloudflare dashboard, open **Realtime** (formerly Calls) and create a **TURN key**. It gives you a **key ID** and an **API token**.
2. Add both as Secrets on the Worker, the same way as `ADMIN_KEY`: `TURN_KEY_ID` and `TURN_KEY_API_TOKEN`.

The server then hands each player short-lived relay passwords automatically. Your TURN key never reaches the browser.

## How players use it

1. Go into Free Roam and tap **Online**.
2. Enter a name and a room code, then tap **Join**. Friends who join the same code appear on the island and on the minimap (blue dots).
3. **Mic on / Mic off** (top bar, or in the panel) turns your microphone on or off.
   - The phone asks for microphone permission the first time.
   - A 🎙 next to a name means that player's mic is on. The name glows green while they're talking.
   - **Only hear drivers near me** fades voices with distance. On iPhone the browser ignores this volume setting, so everyone stays at full volume.
4. The first player in the room is the host. The host (or you, the owner) can pick a race and tap **Start room race**.
5. **Horn:** the Horn button in the panel, or **H** on a keyboard.

## How you, the owner, use it

1. In the **Online** panel, open **Owner**, type your admin key and tap **Live rooms**. You'll see every room with people in it, who's in it, whose mic is on, and whether they're racing.
2. For each room:
   - **Join:** go in as a normal driver.
   - **Watch unseen:** go in without your van appearing and without sending your position. You still see everyone and hear their voices.
     - Players get a short notice that the island owner is listening in. Being honest about that protects you and them.
3. Inside a room:
   - **Go to** puts you next to a player.
   - **Remove** kicks a player out.
   - **Speak to this room** pops a message on every player's screen.

## Limits and cost

- **Room size:** up to 12 drivers per room, plus watchers. Change `MAX_PLAYERS` in `src/worker.js` to allow more.
- **Update rate:** each player sends 10 position updates a second.
- **Cloudflare free plan:** 100,000 requests a day. Cloudflare counts 20 incoming messages as 1 request, so one player online for an hour uses about 1,800. That's roughly 55 player-hours a day for free.
- **Paid plan:** past the free limit, the Workers Paid plan (from $5 a month) includes 1 million requests a month, then $0.15 per extra million.
- **Running cost between messages:** rooms use WebSocket Hibernation, so a room isn't billed for running time while it's just holding connections open.
- **Voice:** goes player to player, so it doesn't count against these limits. Each player connects to every other player in the room, which is fine for a handful of people talking. TURN relay traffic (if you set it up) is billed by Cloudflare Realtime and has its own free allowance.
